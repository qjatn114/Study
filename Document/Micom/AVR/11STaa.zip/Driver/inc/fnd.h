#ifndef _FND_H_
#define _FND_H_

#include "type.h"

void FND_Init(void);
void FND_On(uint8_t Num,uint8_t Digit,uint8_t Dot);
void FND_Write(uint8_t Num,uint8_t Digit,uint8_t Dot);



#endif
