#ifndef _LED_H_
#define _LED_H_

#include "type.h"

void LED_Init(void);
void LED_On(uint8_t Data);






#endif
