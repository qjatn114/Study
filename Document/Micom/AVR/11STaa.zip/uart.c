#include "type.h"




void UART_Init(void)
{

}
void UART_PutChar(uint8_t Data)
{

}

void UART_PutString(const char *String)
{

}

